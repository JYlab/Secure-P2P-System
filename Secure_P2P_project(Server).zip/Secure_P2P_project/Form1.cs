﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using System.Collections;
using System.IO;
using System.Security.Cryptography;



// 바이러스토탈 API키 23964f80447c21a81c6bf9588d28387041a1b15ec6f778544d008f206644b15d

namespace Secure_P2P_project
{
    public partial class Form1 : Form
    {
        public static String IPinfo;
        public static String PORTinfo;
        public static String FilePath;
        public static String FileName;
        Socket mySocket;
        
        IPAddress serverIP;
        int serverPort;
        IPEndPoint point;

        public Form1()
        {

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            configIMG.BackgroundImage = Properties.Resources._1;
        }

        private void configIMG_MouseUp(object sender, MouseEventArgs e)
        {
            configIMG.BackgroundImage = Properties.Resources._0;
        }

        private void pictureBox1_MouseDown_1(object sender, MouseEventArgs e)
        {
            shieldIMG.BackgroundImage = Properties.Resources.shiled1;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            shieldIMG.BackgroundImage = Properties.Resources.shiled0;
        }


        private void FileSend_MouseDown_1(object sender, MouseEventArgs e)
        {
            FileSend.BackgroundImage = Properties.Resources.FileSend1;
        }

        private void FileSend_MouseUp(object sender, MouseEventArgs e)
        {
            FileSend.BackgroundImage = Properties.Resources.FileSend;
        }

        private void configIMG_Click(object sender, EventArgs e)
        {

            Form2 Form2 = new Form2();
            Form2.Show();


        }

        private void ConnectBtn_Click(object sender, EventArgs e)
        {

            serverIP = IPAddress.Parse(IPinfo);
            serverPort = Convert.ToInt32(PORTinfo);

            // 서버 소켓 생성 
            mySocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            // 종단점 생성 
            point = new IPEndPoint(serverIP, 8192);
            // 소켓 바인딩  192.168.152.1
            mySocket.Bind(point);
            // 소켓을 대기 상태로 둠 
            mySocket.Listen(10);
            // 연결한 소켓을 받아들임 
            mySocket = mySocket.Accept();
            ConnectCheck.Text = "Connect";



        }

        private void FileFind_Click(object sender, EventArgs e)
        {

            string fileName = string.Empty;

            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory + "\\XmlData\\";
                dlg.Filter = "텍스트파일 (*.*)|*.*|모든파일 (*.*)|*.*";
                dlg.FilterIndex = 1;
                dlg.RestoreDirectory = true;

                if (dlg.ShowDialog() != DialogResult.OK)
                {
                    return;
                }
                FilePath = dlg.FileName;

            }
                  
        }

        private void FileSend_Click(object sender, EventArgs e)
        {

            // 데이터를 받을 버퍼 생성
            byte[] buffer = new byte[4];
            byte[] namebuffer = new byte[50];

            int length = mySocket.Receive(namebuffer, 0, namebuffer.Length, SocketFlags.None);
            //디코딩&출력

            FileName = Encoding.UTF8.GetString(namebuffer, 0, length);
            MessageBox.Show("받은 데이터 : " + FileName);


            //파일을 만듦
            FileStream fileStr = new FileStream(FileName, FileMode.Create, FileAccess.Write);
            
            // 클라이언트로부터 파일 크기를 받음 
            mySocket.Receive(buffer);
            
            // 받은 데이터를 정수로 변환하고 변수에 저장 
            int fileLength = BitConverter.ToInt32(buffer, 0);
            // 버퍼 크기 새로 지정 
            buffer = new byte[1024];
            
            // 현재까지 받은 파일 크기 변수 
            int totalLength = 0;
            
            
            // 받을 데이터를 파일에 쓰기 위해 BinaryWriter 객체 생성 
            BinaryWriter writer = new BinaryWriter(fileStr);
            // 파일 수신 작업 
            MessageBox.Show("Waiting");
            while (totalLength < fileLength)
            {
             
                int receiveLength = 0;
                if (buffer.Length > (fileLength - totalLength))
                    receiveLength = mySocket.Receive(buffer, fileLength - totalLength, SocketFlags.None);
                else
                    receiveLength = mySocket.Receive(buffer);
                Console.WriteLine("{0}", receiveLength);// recive length 출력
                // 받은 데이터를 파일에 씀 
                writer.Write(buffer, 0, receiveLength);
                // 현재까지 받은 파일 크기를 더함 
                totalLength += receiveLength;
            }
          
            
            // 종료 작업 
            writer.Close();
            mySocket.Close();
            

        }
        

        private void shieldIMG_Click(object sender, EventArgs e)

        {
            //String name = System.Windows.Forms.Application.ExecutablePath;

            String name = System.IO.Directory.GetCurrentDirectory();
            FilePath = name+"\\"+FileName;
            backgroundWorker1.RunWorkerAsync(name+"\\"+FileName);
            
        }

        private void backgroundWorker1_DoWork_1(object sender, DoWorkEventArgs e)
        {
            
            string filePath = e.Argument.ToString();
            byte[] buffer;
            int bytesRead;
            long size;
            long totalBytesRead = 0;

            using (Stream file = File.OpenRead(filePath))
            {
                size = file.Length;

                using (HashAlgorithm hasher = MD5.Create())
                {
                    do
                    {
                        buffer = new byte[4096];

                        bytesRead = file.Read(buffer, 0, buffer.Length);

                        totalBytesRead += bytesRead;

                        hasher.TransformBlock(buffer, 0, bytesRead, null, 0);


                    }
                    while (bytesRead != 0);

                    hasher.TransformFinalBlock(buffer, 0, 0);

                    e.Result = MakeHashString(hasher.Hash);
                }
            }
        }

        private static string MakeHashString(byte[] hashBytes)
        {
            
            StringBuilder hash = new StringBuilder(32);

            foreach (byte b in hashBytes)
                hash.Append(b.ToString("X2").ToLower());
            return hash.ToString();
        }

        private void backgroundWorker1_RunWorkerCompleted_1(object sender, RunWorkerCompletedEventArgs e)
        {
            MessageBox.Show("전송받은 파일의 해쉬값 : \r" + e.Result.ToString());
            MessageBox.Show("해당 해쉬값이 DB에 있는지 확인 중");
            richTextBox1.Clear();
            dataGridView1.Rows.Clear();
            Execute.ScanFile(FilePath, richTextBox1, dataGridView1);

            richTextBox1.ForeColor = Color.DarkBlue;
            richTextBox1.Text = "Scanning in Progress... Please wait!";

        }


    }


}
